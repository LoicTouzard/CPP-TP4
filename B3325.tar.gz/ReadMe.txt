TP4 C++ Héritage et Polymorphisme B3325

La compilation se fait avec le makefile situé dans le src.
L'exécutable est généré dans le dossier racine

Si les tests de performances s'effectuent en redirigeant l'entrée standard vers un fichier de test, il serait bien de rediriger la sortie (>) vers un fichier temporaire afin de ne pas subir les effets des affichages.

